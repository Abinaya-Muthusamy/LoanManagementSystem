
module LMS {
	requires java.sql;
	
}